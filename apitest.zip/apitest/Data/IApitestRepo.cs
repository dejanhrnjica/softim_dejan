// Interface IApitestRepo
// Defines interface for repository objects
using System;
using System.Collections.Generic;
using Apitest.Models;

namespace Apitest.Data
{
    public interface IApitestRepo
    {
        // Returns list of all customer objects 
        IEnumerable<Customer> GetCustomerList();

        // Returns the list of customers that visited the shop in interval from-to 
        IEnumerable<Customer> GetCustomerList(DateTime from, DateTime to);
        
        // Returns customer object with required Id
        Customer GetCustomerById(int id);

        // Creates a customer record in the data source
        void InsertCustomerList(IEnumerable<Customer> customerList);
    }
}