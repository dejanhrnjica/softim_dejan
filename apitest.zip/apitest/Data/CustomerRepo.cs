using System;
using System.Collections.Generic;
using Apitest.Models;

namespace Apitest.Data
{
    public class CustomerRepo : IApitestRepo
    {

        // Returns complete customer list
        public IEnumerable<Customer> GetCustomerList()
        {
            return customerContext.GetCustomerList();
        }

        // Returns the list of customers that visited the shop in interval from-to 
        public IEnumerable<Customer> GetCustomerList(DateTime from, DateTime to)
        {
            return customerContext.GetCustomerList(from, to);
        }
        
        // Returns customer object from data source identified by id
        public Customer GetCustomerById(int id)
        {
            return customerContext.GetCustomerById(id);
        }

        // Insert list of customer records to data source
        public void InsertCustomerList(IEnumerable<Customer> customerList)
        {
            customerContext.InsertCustomerList(customerList);
        }

        // Context object
        private readonly ICustomerContext customerContext = new AzureDbCustomerContext("pzs5t5imun.database.windows.net", "softim_recruit", "TNeANy5SaFDf", "AUTO_ETL_META_DB");
    }
}