// Interface ICustomerContext
// Interface for Customer context objects

using System;
using System.Collections.Generic;
using Apitest.Models;

namespace Apitest.Data
{
    public interface ICustomerContext
    {
        // Returns object list for all customers in the database
        IEnumerable<Customer> GetCustomerList();
        
        // Returns object list for all customers that visited the shop in a date interval
        // from - start of the date interval
        // to - end of the date interval
        IEnumerable<Customer> GetCustomerList(DateTime from, DateTime to);
        
        // Retrurns Customer with specified database id
        // id - database id
        Customer GetCustomerById(int id);

        // Add new record to customer table
        void InsertCustomerList(IEnumerable<Customer> customerList);
    }
}