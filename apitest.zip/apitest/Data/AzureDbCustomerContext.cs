// Class AzureDbCustomerContext implementing ICustomerContext interface
// Context class for Customer data in Azure database

using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Collections.Generic;
using System.Linq;

using Apitest.Models;

namespace Apitest.Data
{
    public class AzureDbCustomerContext : ICustomerContext
    {
        // Constructor
        public AzureDbCustomerContext(string dataSource, // database server url
                               string userID,     // client username
                               string password,   // client password
                               string initialCatalog  // database name
                               )
        {
            var builder = new SqlConnectionStringBuilder();
            builder.DataSource = dataSource; 
            builder.UserID = userID;            
            builder.Password = password;     
            builder.InitialCatalog = initialCatalog;
            connectionString = builder.ConnectionString;
        }
        
        // Returns object list for all customers in the database
        public IEnumerable<Customer> GetCustomerList()
        {
            try
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("SELECT Id, VisitDateTime, Age, WasSatisfied, Sex ");
                sb.Append("FROM [recruit].[Customers]");
                sb.Append("ORDER BY VisitDateTime DESC;");

                return GetCustomerListBase(sb.ToString());
            }
            catch (SqlException exception)
            {
                throw new DataException(exception.ToString());
            }
        }
        
        // Returns object list for all customers that visited the shop in a date interval
        // from - start of the date interval
        // to - end of the date interval
        public IEnumerable<Customer> GetCustomerList(DateTime from, DateTime to)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT Id, VisitDateTime, Age, WasSatisfied, Sex");
            sb.Append(" FROM [recruit].[Customers]");
            sb.Append(" WHERE (VisitDateTime >= '" + from.ToString("yyyy-MM-ddTHH:mm:ss") + "') AND (VisitDateTime <= '" + to.ToString("yyyy-MM-ddTHH:mm:ss") + "')"); 
            sb.Append(" ORDER BY VisitDateTime DESC;");

            return GetCustomerListBase(sb.ToString());
        }
        
        // Returns Customer with specified database id, or NULL, if no such customer
        // id - database id
        public Customer GetCustomerById(int id)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("SELECT t.Id, VisitDateTime, Age, WasSatisfied, Sex");
            sb.Append(" FROM [recruit].[Customers] t");
            sb.Append(" WHERE t.Id = " + id.ToString() + ";"); 

            return GetCustomerListBase(sb.ToString()).FirstOrDefault();
        }

        // Add new record to customer table
        public void InsertCustomerList(IEnumerable<Customer> customerList)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();     
                
                foreach (Customer customer in customerList)
                {
                    StringBuilder sb = new StringBuilder();
                    sb.Append("INSERT INTO [recruit].[Customers] ");
                    sb.Append("( [VisitDateTime], [Age], [WasSatisfied], [Sex])");
                    sb.Append("VALUES");
                    sb.Append("('"+customer.VisitDateTime.ToString("yyyy-MM-ddTHH:mm:ss") + "',"+ customer.Age.ToString()+",'"+customer.WasSatisfied.ToString()+"','"+customer.Sex.ToString()+"');");
                    string query = sb.ToString();      

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.ExecuteNonQuery();
                    }
                }

                connection.Close();
            }
        }

        // Returns the list of customers corresponding to SELECT sql query
        // selectQuery - select sql; query
        protected IEnumerable<Customer> GetCustomerListBase(string selectQuery)
        {
            var customerList = new List<Customer>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();       
                
                using (SqlCommand command = new SqlCommand(selectQuery, connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            int id;
                            int.TryParse(reader[0].ToString(), out id);
                            DateTime visitDateTime;
                            DateTime.TryParse(reader[1].ToString(), out visitDateTime);
                            int age;
                            int.TryParse(reader[2].ToString(), out age);
                            bool wasSatisfied;
                            bool.TryParse(reader[3].ToString(), out wasSatisfied);
                            char sex;
                            char.TryParse(reader[4].ToString(), out sex);

                            customerList.Add(new Customer{Id=id, VisitDateTime=visitDateTime, Age=age, WasSatisfied=wasSatisfied, Sex=sex});
                        }
                    }
                }                    
            }

            return customerList;
        }
        //
        // database connection parameters
        //
        private string connectionString;
    }
}