// Class CustomerMapper
// Mapping customer object to/from DTO object

using System;
using Apitest.Models;

namespace Apitest.Dto
{
    public class CustomerMapper
    {
        // Conversion from Customer object to dto when reading data
        public static CustomerReadDto CustomerToReadDto(Customer customer)
        {
            return new CustomerReadDto
            {
                Id = customer.Id,
                VisitDateTime = customer.VisitDateTime,
                Age = customer.Age,
                WasSatisfied = customer.WasSatisfied,
                Sex = customer.Sex
            };
        }

        // Conversion from dto to Customer object when inserting customers
        public static Customer CreateDtoToCustomer(CustomerCreateDto dto)
        {
            return new Customer
            {
                Id = 0,
                VisitDateTime = dto.VisitDateTime,
                Age = dto.Age,
                WasSatisfied = dto.WasSatisfied,
                Sex = dto.Sex
            };
        }
    }
}