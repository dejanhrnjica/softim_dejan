// Class TimeIntervalDto
// DTO object representing a time interval

using System;
using System.ComponentModel.DataAnnotations;

namespace   Apitest.Dto
{
    public class TimeIntervalDto
    {
        // Start
        [Required]
        public DateTime Start{get;set;}
        
        // End
        [Required]
        public DateTime End {get; set;}
    }
}