// Class CustomerReadDto
// DTO object used to send selected customer data back to client from server

using System;
using System.ComponentModel.DataAnnotations;

namespace   Apitest.Dto
{
    public class CustomerReadDto  
    {
        [Required]
        public int Id {get; set;}
        [Required]
        public DateTime VisitDateTime {get; set;}
        [Required]
        public int Age {get; set;}
        [Required]
        public bool WasSatisfied {get; set;}
        [Required]
        public char Sex {get; set;}
    }
}