// Class CustomerCreateDto
// DTO object from client to server, creating new customer record in the data source

using System;
using System.ComponentModel.DataAnnotations;

namespace   Apitest.Dto
{
    public class CustomerCreateDto  
    {
        [Required]
        public DateTime VisitDateTime {get; set;}
        [Required]
        public int Age {get; set;}
        [Required]
        public bool WasSatisfied {get; set;}
        [Required]
        public char Sex {get; set;}
    }
}