using System;
using System.Collections;
using System.Collections.Generic;
using Apitest.Models;
using Apitest.Data;
using Apitest.Dto;
using Microsoft.AspNetCore.Mvc;

namespace ApitestController
{
    /// <summary>
    /// Controller for Customer database services
    /// </summary>
    [Route ("api/customers")]
    [ApiController]
    public class CustomersController : ControllerBase
    {
        // Constructor
        // repo - repository
        public CustomersController(IApitestRepo repo)
        {
            repository = repo;
        }

        /// <summary>
        /// Returns the list of objects for customers, that visited the shop in specified interval 
        /// </summary>
        [HttpGet]
        public ActionResult <IEnumerable<Customer>> ReadCustomers(TimeIntervalDto interval)
        {
            try
            {
                var customerList = repository.GetCustomerList(interval.Start, interval.End);
                return Ok(customerList);
            }
            catch (Exception exception)
            {
                Console.WriteLine("Apitest::ReadCustomers exception:");
                Console.WriteLine(exception.ToString());
                return NoContent();
            }
        }

        /// <summary>
        /// Add new customers to the customer database 
        /// </summary>
        [HttpPost]
        public ActionResult <CustomerReadDto> InsertCustomers(List<CustomerCreateDto> createDtoList)
        {
            try
            {
                var customerList = new List<Customer>(); 
                foreach(CustomerCreateDto createDto in createDtoList)
                {
                    customerList.Add(CustomerMapper.CreateDtoToCustomer(createDto));
                }

                repository.InsertCustomerList(customerList);
                return Ok();
            }
            catch (Exception exception)
            {
                Console.WriteLine("Apitest::ReadCustomers exception:");
                Console.WriteLine(exception.ToString());
                return NoContent();
            }
        }

        private readonly IApitestRepo repository;
    }
}