// Class Customer
// Customer data structure

using System;
using System.ComponentModel.DataAnnotations;

namespace   Apitest.Models
{
    public class Customer  
    {
        [Key]
        public int Id {get; set;}

        [Required]
        public DateTime VisitDateTime {get; set;}
        
        [Required]
        [Range(5, 120, ErrorMessage = "Can only be between 5 .. 120")]
        public int Age {get; set;}
        
        [Required]
        public bool WasSatisfied {get; set;}
        
        [Required]
        public char Sex {get; set;}
    }
}